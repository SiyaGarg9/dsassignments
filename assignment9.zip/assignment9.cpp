#include <iostream>
using namespace std;
struct Edge {
    int u, v, w;
};
class Graph {
public:
    int V;
    int adj[50][50];
    Graph(int V) {
        this->V = V;
        for (int i = 0; i < V; i++)
            for (int j = 0; j < V; j++)
                adj[i][j] = 0;
    }

    void addEdge(int u, int v, int w) {
        adj[u][v] = w;
        adj[v][u] = w;
    }

    void BFS(int start) {
        int q[100], front = 0, rear = 0;
        int visited[50];
        for (int i = 0; i < V; i++) visited[i] = 0;

        visited[start] = 1;
        q[rear++] = start;

        cout << "BFS: ";
        while (front < rear) {
            int node = q[front++];
            cout << node << " ";

            for (int i = 0; i < V; i++) {
                if (adj[node][i] != 0 && !visited[i]) {
                    visited[i] = 1;
                    q[rear++] = i;
                }
            }
        }
        cout << endl;
    }

    void DFSUtil(int node, int visited[]) {
        visited[node] = 1;
        cout << node << " ";
        for (int i = 0; i < V; i++) {
            if (adj[node][i] != 0 && !visited[i]) {
                DFSUtil(i, visited);
            }
        }
    }

    void DFS(int start) {
        int visited[50];
        for (int i = 0; i < V; i++) visited[i] = 0;
        cout << "DFS: ";
        DFSUtil(start, visited);
        cout << endl;
    }
};

int findSet(int parent[], int i) {
    if (parent[i] == i) return i;
    return parent[i] = findSet(parent, parent[i]);
}

void unionSet(int parent[], int rank[], int x, int y) {
    if (rank[x] < rank[y]) parent[x] = y;
    else if (rank[x] > rank[y]) parent[y] = x;
    else {
        parent[y] = x;
        rank[x]++;
    }
}

void Kruskal(int V, Edge edges[], int E) {
    for (int i = 0; i < E - 1; i++) {
        for (int j = 0; j < E - i - 1; j++) {
            if (edges[j].w > edges[j + 1].w) {
                Edge temp = edges[j];
                edges[j] = edges[j + 1];
                edges[j + 1] = temp;
            }
        }
    }

    int parent[50], rank[50];
    for (int i = 0; i < V; i++) {
        parent[i] = i;
        rank[i] = 0;
    }

    cout << "Kruskal MST:\n";
    int cost = 0;

    for (int i = 0; i < E; i++) {
        int x = findSet(parent, edges[i].u);
        int y = findSet(parent, edges[i].v);
        if (x != y) {
            cout << edges[i].u << " - " << edges[i].v << " (" << edges[i].w << ")\n";
            cost += edges[i].w;
            unionSet(parent, rank, x, y);
        }
    }
    cout << "Total cost = " << cost << "\n\n";
}

void Prim(Graph &g) {
    int V = g.V;
    int key[50], parent[50], mstSet[50];

    for (int i = 0; i < V; i++) {
        key[i] = 999999;
        mstSet[i] = 0;
        parent[i] = -1;
    }

    key[0] = 0;

    for (int count = 0; count < V - 1; count++) {
        int u = -1;
        for (int v = 0; v < V; v++)
            if (!mstSet[v] && (u == -1 || key[v] < key[u]))
                u = v;

        mstSet[u] = 1;

        for (int v = 0; v < V; v++) {
            if (g.adj[u][v] != 0 && !mstSet[v] && g.adj[u][v] < key[v]) {
                parent[v] = u;
                key[v] = g.adj[u][v];
            }
        }
    }

    cout << "Prim MST:\n";
    int cost = 0;
    for (int i = 1; i < V; i++) {
        cout << parent[i] << " - " << i << " (" << key[i] << ")\n";
        cost += key[i];
    }
    cout << "Total cost = " << cost << "\n\n";
}

void Dijkstra(Graph &g, int src) {
    int V = g.V;
    int dist[50], visited[50];

    for (int i = 0; i < V; i++) {
        dist[i] = 999999;
        visited[i] = 0;
    }

    dist[src] = 0;

    for (int count = 0; count < V - 1; count++) {
        int u = -1;
        for (int i = 0; i < V; i++)
            if (!visited[i] && (u == -1 || dist[i] < dist[u]))
                u = i;

        visited[u] = 1;

        for (int v = 0; v < V; v++) {
            if (g.adj[u][v] != 0 && dist[u] + g.adj[u][v] < dist[v]) {
                dist[v] = dist[u] + g.adj[u][v];
            }
        }
    }

    cout << "Dijkstra distances from " << src << ":\n";
    for (int i = 0; i < V; i++)
        cout << "Node " << i << ": " << dist[i] << endl;
    cout << endl;
}

int main() {
    int V = 5;
    Graph g(V);

    g.addEdge(0, 1, 2);
    g.addEdge(0, 2, 4);
    g.addEdge(1, 2, 1);
    g.addEdge(1, 3, 7);
    g.addEdge(2, 4, 3);
    g.addEdge(3, 4, 1);

    g.BFS(0);
    g.DFS(0);

    Edge edges[] = {
        {0,1,2},{0,2,4},{1,2,1},{1,3,7},{2,4,3},{3,4,1}
    };
    Kruskal(V, edges, 6);

    Prim(g);
    Dijkstra(g, 0);

    return 0;
}


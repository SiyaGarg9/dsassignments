#include <iostream>
using namespace std;
class Node{
	public:
int data;
Node *Next;
	
};
int main(){
	Node *Start=NULL, *ptr, *temp, *temp1;
	int i;
	while(1==1){
	cout<<"\n1 to insert data" ;     ;
	cout<<"\n2 to display";
	cout<<" \n3 to search a number";
	cout<<"\n4 to insert at beginning";
	cout<<"\n5 for insertion at end";
	cout<<"\n6 for insertion after specific value";
	cout<<"\n7 for deletion from beginning";
	cout<<"\n8 for deletion from end";
	cin>>i;
	if(i==1){
	
	ptr=new Node();
	cin>>ptr->data;
	ptr->Next=NULL;
	if(Start==NULL){
		Start=ptr;
		ptr->Next=Start;
	}
	else{
		temp=Start;
		while(temp->Next!=Start){
			temp=temp->Next;
		}
		temp->Next=ptr;
		ptr->Next=Start;
	}}
	if(i==2){
		temp=Start;
	do{
			cout<<temp->data;
			temp=temp->Next;
		}while(temp!=Start);
		
	}
	if(i==3){
	int n,f=0; 
		cout<<"enter the number to be searched";
		cin>>n;
		temp=Start;
		do{
			if(temp->data==n){
				cout<<"element found";
			f=1;
			
			}
				temp=temp->Next;
		}while(temp!=Start);
		if(f==0){
			cout<<"Element not found";
		}
		
	}
	if(i==4){
		ptr=new Node();
	    cin>>ptr->data;
		ptr->Next=NULL;
	if(Start==NULL){
		Start=ptr;
		ptr->Next=Start;
	}
	else{
		temp=Start;
		while(temp->Next!=Start){
			temp=temp->Next;
		}
		temp->Next=ptr;
		ptr->Next=Start;
		Start=ptr;
		}
	
		
	}
	if(i==5){
		ptr=new Node();
		cout<<"Enter the value= ";
		cin>>ptr->data;
		ptr->Next=NULL;
	if(Start==NULL){
		Start=ptr;
		ptr->Next=Start;
	}
	else{
		temp=Start;
		while(temp->Next!=Start){
			temp=temp->Next;
		}
		temp->Next=ptr;
		ptr->Next=Start;}
		
	}
	if(i==6){
		ptr=new Node();
		cout<<"Enter the value= ";
		cin>>ptr->data;
		int k;
		cout<<"Enter the before value";
		cin>>k;
		int f=0;
		do{
			if(temp->data==k){
				
			f=1;
			break;
			}
				temp=temp->Next;
		}while(temp!=Start);
		if(f==1){
			ptr->Next=temp->Next;
			temp->Next=ptr;
			
		}
	}
	if(i==7){
		if(Start==NULL){
		Start=ptr;
		ptr->Next=Start;
	}
	else{
		temp=Start;
		while(temp->Next!=Start){
			temp=temp->Next;
		}
	
		Start=Start->Next;
	    ptr->Next=Start;
		}
		
	}
	if(i==8){
		temp=Start;
		while(temp->Next!=Start){
			temp=temp1;
			temp=temp->Next;
		}
	
		temp1=temp1->Next;
	    temp1->Next=Start;
		}
		
	}
}

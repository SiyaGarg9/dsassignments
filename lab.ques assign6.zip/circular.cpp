#include <iostream>
using namespace std;

class Node {
    public:
    int data;
    Node *Next;
};

int main() {
    Node *Start = NULL, *ptr, *temp, *temp1;
    int i;

    while (1 == 1) {
        cout << "\n1 to enter the data \n2 to display the data \n3 to search a number  \n4 for insertion at beginning \n5 insertion at end \n6 insertion after given value";
        
		cout<<"\n7 for del from beginning";
		cin >> i;

        if (i == 1) {
            ptr = new Node();
            cout << "Enter value: ";
            cin >> ptr->data;

            if (Start == NULL) {
                Start = ptr;
                ptr->Next = Start;  // circular connection for first node
            } else {
                temp = Start;
                while (temp->Next != Start) {  // stop at last node
                    temp = temp->Next;
                }
                temp->Next = ptr;
                ptr->Next = Start;  // link back to Start
            }
        }

        if (i == 2) {
            if (Start == NULL) {
                cout << "List is empty" << endl;
            } else {
                temp = Start;
                do {
                    cout << temp->data << " ";
                    temp = temp->Next;
                } while (temp != Start);  // stop when back at Start
                cout << endl;
            }
        }if(i==3){
        int k,f=0;
		cout<<"Enter the element to be searched ";
		cin>>k;
		temp=Start;
			do{
				if(temp->data==k){
					cout<<"\nElement found";
					f=1;
				}
				temp=temp->Next;
			}while(temp!=Start);
        	if(f==0){
        		cout<<"Element not found";
			}
		}
		if(i==4){
			ptr = new Node();
            cout << "Enter value: ";
            cin >> ptr->data;

            if (Start == NULL) { // first node
                Start = ptr;
                ptr->Next = Start;
            } else {
                temp = Start;
                while (temp->Next != Start) { // go to last node
                    temp = temp->Next;
                }
                temp->Next =ptr; // last node points to new node
                ptr->Next = Start; // new node points to old Start
                Start = ptr;       // update Start to new node
            }
		}
		if(i==5){
				 ptr = new Node();
            cout << "Enter value: ";
            cin >> ptr->data;

            if (Start == NULL) {
                Start = ptr;
                ptr->Next = Start;
            } else {
                temp = Start;
                while (temp->Next != Start) {
                    temp = temp->Next;
                }
                temp->Next = ptr;
                ptr->Next = Start;
            }
		}
		if(i==6){
		if (Start == NULL) {
                cout << "List is empty, cannot insert after a value" << endl;
            } else {
                int key;
                cout << "Enter value after which to insert: ";
                cin >> key;

                temp = Start;
                int found = 0;
                do {
                    if (temp->data == key) {
                        found = 1;
                        break;
                    }
                    temp = temp->Next;
                } while (temp != Start);

                if (found==0) {
                    cout << "Value " << key << " not found in the list." << endl;
                } else {
                    ptr=new Node();
                    cout << "Enter value to insert: ";
                    cin >> ptr->data;

                    ptr->Next = temp->Next;
                    temp->Next=ptr;
                }
            }
			
		}
		if(i==7){
			 if (Start == NULL) {
                cout << "List is empty" << endl;
            } else {
                int key;
                cout << "Enter value to delete: ";
                cin >> key;
                do{
                	temp1=temp;
                	temp=temp->Next;
                	
                	if(temp->data==key){
                		temp1->Next=temp->Next;
                		
					}
				}while(temp!=Start);
			
			
		}
}
        
    }

    return 0;
}


#include <iostream>
using namespace std;
class Node {
public:
    char data;
    Node *Next, *Prev;
};
int main() {
    Node *Start = NULL, *ptr, *temp, *temp1;
    int choice;

    while (1) {
        cout << "\n1. Enter data";
        cout << "\n2. Display list";
        cout << "\n3. Check Palindrome";
        cin >> choice;
        if (choice == 1) {
            ptr = new Node();
            cout << "Enter character: ";
            cin >> ptr->data;
            ptr->Next=NULL;
            ptr->Prev=NULL;
            if (Start==NULL) {
                Start = ptr;
            } else {
                temp = Start;
                while (temp->Next != NULL)
                    temp = temp->Next;
                temp->Next = ptr;
                ptr->Prev = temp;
            }
        }

        if (choice == 2) {
            if (Start == NULL)
                cout << "List is empty.";
            else {
                temp = Start;
                cout << "Doubly Linked List: ";
                while (temp != NULL) {
                    cout << temp->data << " ";
                    temp = temp->Next;
                }
            }
        }
        if (choice == 3) {
            if (Start == NULL) {
                cout << "List is empty.";
            } else {
                Node *head = Start;
                temp1=Start;
                while (temp1->Next != NULL)
                    temp1 =temp1->Next;
                bool palindrome = true;
                while (head != temp1 && temp1->Next != head) {
                    if (head->data !=temp1->data) {
                        palindrome = false;
                        break;
                    }
                    head = head->Next;
                   temp1=temp1->Prev;
                }

                if(palindrome)
                    cout<<"\n is Palindrome.";
                else
                    cout << "\n not Palindrome.";
            }
        }

       
    }

    return 0;
}


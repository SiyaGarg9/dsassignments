#include <iostream>
using namespace std;
class Node{
	public:
	int data;
	Node *Next;
	Node *prev;
};
main(){
	Node *Start=NULL, *temp,*ptr,*temp1;
	int i;
	while(1==1){
	 cout<<"\n1 for data \n2 for display \n3 insertion at beginning \n4 insertion at end \n5 for del \n6 for del at end \n";
	 cin>>i;
	 if (i==1){
	 ptr=new Node();
	 cin>>ptr->data;
	 ptr->Next=NULL;
	if(Start==NULL){
		Start=ptr;
		ptr->prev=NULL;
	} else{
		temp=Start;
		while(temp->Next!=NULL){
			
			temp=temp->Next;
	   		
		}
		temp->Next=ptr;
		ptr->prev=temp;
	}
	 	
	}
	if(i==2){
		temp=Start;
		while(temp!=NULL){
		cout<<temp->data;
		temp=temp->Next;	
			
		}
		
	}
	if(i==3){
		ptr=new Node();
		cin>>ptr->data;
		ptr->Next=Start;
		Start->prev=ptr;
		Start=ptr;
	}
	if(i==4){
		ptr=new Node();
		cin>>ptr->data;
		while(temp->Next!=NULL){
			
			temp=temp->Next;
		}
		temp->Next=ptr;
		ptr->prev=temp;
		
		
		
	}
	if(i==5){
		Start=Start->Next;
		Start->Next->prev=NULL;
	}
	if(i==6){
		while(temp->Next!=NULL){
			temp=temp->Next;
			
		}
		temp->prev->Next=NULL;
	}
	
	
	
	
	}
	
}

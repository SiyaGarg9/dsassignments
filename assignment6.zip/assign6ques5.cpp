#include <iostream>
using namespace std;
class Node {
public:
    int data;
    Node* Next;
};

int main() {
    Node *Start=NULL, *ptr, *temp;
    int choice;

    while (1) {
        cout << "\n1. Enter data";
        cout << "\n2. Display list";
        cout << "\n3. Make Circular";
        cout << "\n4. Check if Circular";
        cout << "\nEnter your choice: ";
        cin >> choice;

        if (choice==1) {
            ptr=new Node();
            cout<< "Enter value: ";
            cin>>ptr->data;
            ptr->Next=NULL;

            if (Start==NULL) {
                Start=ptr;
            } else {
                temp=Start;
                while (temp->Next!= NULL&&temp->Next!=Start)
                    temp = temp->Next;
                temp->Next = ptr;
            }
        }
        if (choice==2) {
            if (Start==NULL)
                cout<<"List is empty.";
            else {
                temp=Start;
                cout<<"Linked List: ";
                while (temp!=NULL && temp->Next != Start) {
                    cout<<temp->data << " ";
                    temp=temp->Next;
                }
                if (temp!= NULL)
                    cout << temp->data; 
            }
        }

        if (choice == 3) {
            if (Start == NULL)
                cout << "List is empty.";
            else {
                temp = Start;
                while (temp->Next != NULL)
                    temp = temp->Next;
                temp->Next = Start;
                cout << "\nLinked list made circular successfully!";
            }
        }

        if (choice == 4) {
            if (Start == NULL) {
                cout << "List is empty.";
            } else {
                temp = Start->Next;
                bool circular=false;
                while (temp!= NULL) {
                    if (temp== Start) {
                        circular=true;
                        break;
                    }
                    temp=temp->Next;
                }

                if (circular)
                    cout<< "is Circular.";
                else
                    cout<< " not Circular.";
            }
        }

       
    }

    return 0;
}


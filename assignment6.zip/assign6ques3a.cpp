#include <iostream>
using namespace std;
class Node{
	public:
	int data;
	Node *Next;
	Node *prev;
};
main(){
	Node *Start=NULL, *temp,*ptr,*temp1;
	int i;
	while(1==1){
	 cout<<"\n1 for data \n2 for display \n3 for size ";
	 cin>>i;
	 if (i==1){
	 ptr=new Node();
	 cin>>ptr->data;
	 ptr->Next=NULL;
	if(Start==NULL){
		Start=ptr;
		ptr->prev=NULL;
	} else{
		temp=Start;
		while(temp->Next!=NULL){
			
			temp=temp->Next;
	   		
		}
		temp->Next=ptr;
		ptr->prev=temp;
	}
	 	
	}
	if(i==2){
		temp=Start;
		while(temp!=NULL){
		cout<<temp->data;
		temp=temp->Next;	
			
		}
		
	}
	if(i==3){
		int m=0;
		if(Start==NULL){
		cout<<"m=0";
	} else{
		temp=Start;
		while(temp!=NULL){
			m=m+1;
			temp=temp->Next;
	   		
		}
	cout<<m;
	}
}
}
	}

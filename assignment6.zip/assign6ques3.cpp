#include <iostream>
using namespace std;

class Node {
    public:
    int data;
    Node *Next;
};

int main() {
    Node *Start = NULL, *ptr, *temp, *temp1;
    int i;

    while (1 == 1) {
        cout << "\n1 to enter the data \n2 to display the data ";
        cout<<"\n3 to display size";
		cin >> i;

        if (i == 1) {
            ptr = new Node();
            cout << "Enter value: ";
            cin >> ptr->data;

            if (Start == NULL) {
                Start = ptr;
                ptr->Next = Start;  
            } else {
                temp = Start;
                while (temp->Next != Start) {  
                    temp = temp->Next;
                }
                temp->Next = ptr;
                ptr->Next = Start;  
            }
        }

        if (i == 2) {
            if (Start == NULL) {
                cout << "List is empty" << endl;
            } else {
                temp = Start;
                do {
                    cout << temp->data << " ";
                    temp = temp->Next;
                } while (temp != Start);  
            }
			
	    	}
	    	if(i==3){
	    		int m=0;

            if (Start == NULL) {
               cout<<"m=0";
            } else {
                temp = Start;
                while (temp->Next != Start) {  
                    
                    m=m+1;
                    temp=temp->Next;
                }
               m=m+1;
			  cout<<m;
            }
	    		
	    		
			}
			}
		
			}

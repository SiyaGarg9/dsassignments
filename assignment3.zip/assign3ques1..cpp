#include <iostream>
using namespace std;

#define MAX 5

int stackArr[MAX];
int top = -1;


void push(int x) {
    if (top == MAX - 1) {
        cout << "Stack Overflow "<< x <<endl;
    } else {
        stackArr[++top] = x;
        cout << x << "pushed into stack."<<"\n";
    }
}


void pop() {
    if (top == -1) {
        cout << "Stack Underflow! Nothing to pop." << endl;
    } else {
        cout << stackArr[top--] <<"popped from stack." <<endl;
    }
}

void isEmpty() {
    if (top == -1)
        cout << "Stack is empty.\n";
    else
        cout << "Stack is not empty.\n";
}

void isFull() {
    if (top == MAX - 1)
        cout << "Stack is full.\n";
    else
        cout << "Stack is not full.\n";
}

void display() {
    if (top == -1) {
        cout << "Stack is empty." << endl;
    } else {
        cout << "Stack elements (top to bottom): ";
        for (int i = top; i >= 0; i--) {
            cout << stackArr[i] << " ";
        }
        cout << endl;
    }
}


void peek() {
    if (top == -1) {
        cout << "Stack is empty" << endl;
    } else {
        cout << "Top element is: " <<stackArr[top] << endl;
    }
}

int main() {
  
    push(10);
    push(20);
    push(30);

    display();
    peek();

    pop();
    display();

    isEmpty();
    isFull();

    push(40);
    push(50);
    push(60); 
    display();

    peek();
    isEmpty();
    isFull();

    return 0;
}


#include <iostream>
#include <cstring>
using namespace std;
#define MAX 100
int precedence(char op) {
    if (op=='^')
        return 3;
    else if (op =='*'||op =='/')
        return 2;
    else if (op =='+'||op =='-')
        return 1;
    else
        return 0;
}

int main() {
    char infix[MAX], postfix[MAX], stack[MAX];
    int top = -1;
    int j = 0;

    cout << "Enter an infix expression: ";
    cin >> infix;

    for (int i = 0; infix[i] != '\0'; i++) {
        char ch = infix[i];

      
        if ((ch >='a'&&ch <='z') ||(ch>='A'&& ch <= 'Z')||(ch>='0'&&ch<='9')) {
            postfix[j++] = ch;
        }
  
        else if (ch=='('){
            stack[++top]= ch;
        }
   
        else if(ch ==')') {
            while (top!=-1&&stack[top]!='(') {
                postfix[j++] = stack[top--];
            }
            if (top!=-1) top--;
        }

        else {
            while (top != -1 && precedence(stack[top]) >= precedence(ch)) {
                postfix[j++] = stack[top--];
            }
            stack[++top] = ch;
        }
    }
    while (top != -1) {
        postfix[j++] = stack[top--];
    }

    postfix[j] = '\0';

    cout<<"Postfix expression:"<< postfix << endl;

    return 0;
}


#include <iostream>
#include <cstring>
using namespace std;

int main() {
    char expr[100];
    int stack[100];
    int top = -1;

    cout << "Enter postfix expression: ";
    cin >> expr;

    for (int i = 0; expr[i] != '\0'; i++) {
        char ch = expr[i];
        if (ch >= '0' && ch <= '9') {
            stack[++top] = ch - '0';  
        }
        else {
            int b = stack[top--];
            int a = stack[top--];

            if (ch == '+')
                stack[++top] = a + b;
            else if (ch == '-')
                stack[++top] = a - b;
            else if (ch == '*')
                stack[++top] = a * b;
            else if (ch == '/')
                stack[++top] = a / b;
            else if (ch == '^') {
                int res = 1;
                for (int k = 0; k < b; k++)
                    res *= a;
                stack[++top] = res;
            }
        }
    }
    cout << "Result of postfix expression: " << stack[top] << endl;

    return 0;
}


#include <iostream>
using namespace std;
#define MAX 100
int main() {
    char expr[MAX];
    char stack[MAX];
    int top = -1;

    cout<<"Enter an expression: ";
    cin>>expr;

    bool balanced=true;

    for (int i=0; expr[i]!='\0';i++) {
        char ch=expr[i];

        if (ch=='('||ch=='{'||ch=='[') {
            stack[++top] = ch;
        }
 
        else if (ch==')'||ch=='}'||ch==']') {
            if(top==-1) {  
                balanced=false;
                break;
            }

            char topChar=stack[top--];  

            if ((ch==')' && topChar!='(') ||
                (ch=='}' && topChar!='{') ||
                (ch==']' && topChar!='[')) {
                balanced = false;
                break;
            }
        }
    }

    if (top != -1) balanced = false;

    if (balanced)
        cout << "Expression has balanced parentheses." << endl;
    else
        cout << "Expression does NOT have balanced parentheses." << endl;

    return 0;
}


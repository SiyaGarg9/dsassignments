#include <iostream>
using namespace std;
int main(){
	char a[20],b[20], c[100];
	gets(a);
	cout<<a;
	cout<<"\n";
	gets(b);
	cout<<b;
	int k=0;
  for(int i=0; a[i]!='\0'; i++){
  	c[k]=a[i];
  	k++;
  }
	for(int j=0; b[j]!='\0'; j++){	
		c[k]=b[j];
		k++;
	}
	c[k]='\0';
	cout<<"\n"<<"The concatenated string is "<<c;
	
	return 0;
}

#include <iostream>
using namespace std;
int main(){
	 char ch;
    cout << "Enter an uppercase character: ";
    cin >> ch;
    if (ch>= 'A' && ch <='Z') {  
        char lower = ch + 32;      
        cout << "Lowercase character: " << lower << endl;
    } else {
        cout << "The character is not uppercase!"<< endl;
    }

    return 0;
	
	
	
	
	
	}
	

#include <iostream>
using namespace std;
int main(){
	int a[5]={1,2,3,5,6};
	int i;
	int mis=0;
	for(i=0; i<5; i++){
		if(a[i]!=i){
		mis=i;	
		} else{
			i++;
		}
	}
	if(mis==0){
		cout<<"no number is missing";
	} else{
		cout<<mis<<" is missing";
	}
	return 0;
}

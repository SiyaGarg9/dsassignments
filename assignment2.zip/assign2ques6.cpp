#include <iostream>
using namespace std;

int main() {
    int a[20][3], b[20][3], c[40][3], d[40][3];
    int i, j, k, l;

  
    cout << "Enter rows, cols, non-zero elements of 1st matrix: ";
    cin >> a[0][0] >> a[0][1] >> a[0][2];
    cout << "Enter row col value:\n";
    for (i = 1; i <= a[0][2]; i++)
        cin >> a[i][0] >> a[i][1] >> a[i][2];

    cout << "Enter rows, cols, non-zero elements of 2nd matrix: ";
    cin >> b[0][0] >> b[0][1] >> b[0][2];
    cout << "Enter row col value:\n";
    for (i = 1; i <= b[0][2]; i++)
        cin >> b[i][0] >> b[i][1] >> b[i][2];

   
    cout << "\nTranspose of first matrix:\n";
    d[0][0] = a[0][1];
    d[0][1] = a[0][0];
    d[0][2] = a[0][2];
    k = 1;
    for (i = 0; i < a[0][1]; i++) {
        for (j = 1; j <= a[0][2]; j++) {
            if (a[j][1] == i) {
                d[k][0] = a[j][1];
                d[k][1] = a[j][0];
                d[k][2] = a[j][2];
                k++;
            }
        }
    }
    cout << "Row Col Val\n";
    for (i = 0; i <= d[0][2]; i++)
        cout << d[i][0] << "   " << d[i][1] << "   " << d[i][2] << endl;

   
    cout << "\nAddition of two matrices:\n";
    if (a[0][0] != b[0][0] || a[0][1] != b[0][1]) {
        cout << "Addition not possible\n";
    } else {
        i = j = k = 1;
        c[0][0] = a[0][0];
        c[0][1] = a[0][1];
        while (i <= a[0][2] && j <= b[0][2]) {
            if (a[i][0] < b[j][0] || (a[i][0] == b[j][0] && a[i][1] < b[j][1])) {
                c[k][0] = a[i][0];
                c[k][1] = a[i][1];
                c[k][2] = a[i][2];
                i++; k++;
            } else if (b[j][0] < a[i][0] || (b[j][0] == a[i][0] && b[j][1] < a[i][1])) {
                c[k][0] = b[j][0];
                c[k][1] = b[j][1];
                c[k][2] = b[j][2];
                j++; k++;
            } else {
                c[k][0] = a[i][0];
                c[k][1] = a[i][1];
                c[k][2] = a[i][2] + b[j][2];
                i++; j++; k++;
            }
        }
        while (i <= a[0][2]) {
            c[k][0] = a[i][0];
            c[k][1] = a[i][1];
            c[k][2] = a[i][2];
            i++; k++;
        }
        while (j <= b[0][2]) {
            c[k][0] = b[j][0];
            c[k][1] = b[j][1];
            c[k][2] = b[j][2];
            j++; k++;
        }
        c[0][2] = k - 1;
        cout << "Row Col Val\n";
        for (i = 0; i <= c[0][2]; i++)
            cout << c[i][0] << "   " << c[i][1] << "   " << c[i][2] << endl;
    }

  
    cout << "\nMultiplication of two matrices:\n";
    if (a[0][1] != b[0][0]) {
        cout << "Multiplication not possible\n";
    } else {
      
        int bt[20][3];
        bt[0][0] = b[0][1];
        bt[0][1] = b[0][0];
        bt[0][2] = b[0][2];
        l = 1;
        for (i = 0; i < b[0][1]; i++) {
            for (j = 1; j <= b[0][2]; j++) {
                if (b[j][1] == i) {
                    bt[l][0] = b[j][1];
                    bt[l][1] = b[j][0];
                    bt[l][2] = b[j][2];
                    l++;
                }
            }
        }

        k = 1;
        c[0][0] = a[0][0];
        c[0][1] = bt[0][0];
        for (i = 1; i <= a[0][2]; i++) {
            for (j = 1; j <= bt[0][2]; j++) {
                if (a[i][1] == bt[j][1]) {
                    int row = a[i][0];
                    int col = bt[j][0];
                    int val = a[i][2] * bt[j][2];

                    int found = 0;
                    for (int m = 1; m < k; m++) {
                        if (c[m][0] == row && c[m][1] == col) {
                            c[m][2] += val;
                            found = 1;
                            break;
                        }
                    }
                    if (!found) {
                        c[k][0] = row;
                        c[k][1] = col;
                        c[k][2] = val;
                        k++;
                    }
                }
            }
        }
        c[0][2] = k - 1;
        cout << "Row Col Val\n";
        for (i = 0; i <= c[0][2]; i++)
            cout << c[i][0] << "   " << c[i][1] << "   " << c[i][2] << endl;
    }

    return 0;
}


#include <iostream>
using namespace std;
int main(){
	char a[10], b[10];
	cin.getline(a,10);

	int n=0;
	for(int i=0; a[i]!='\0'; i++){
		n=n+1;
	}
	for(int i=0; i<n/2; i++){
		a[i]=a[n-i-1]+a[i];
		a[n-i-1]=a[i]-a[n-i-1];
		a[i]=a[i]-a[n-i-1];
	}
	cout<<a;
	return 0;
}

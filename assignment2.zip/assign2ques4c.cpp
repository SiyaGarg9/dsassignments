#include <iostream>
using namespace std;
int main(){
	char a[10];
	cin.getline(a,10);
	int k=0; 
	for( int i=0; a[i]!='\0'; i++){
		if(!(a[i]=='a'||a[i]=='e'||a[i]=='i'||a[i]=='o'||a[i]=='u')){
			a[k]=a[i];
			 k++;
			 
		}
	}
	a[k]='\0';
	
	cout<<a;
	return 0;
}

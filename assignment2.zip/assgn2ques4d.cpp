#include <iostream>
using namespace std;
int main(){
	char a[10];
	cin.getline(a,10);
	int i, n=0;
	for(i=0; a[i]!='\0'; i++){
		n=n+1;
	}
	for(i=0; i<n; i++){
		for(int j=0 ; j<n-i-1; j++){
			if (a[j]>a[j+1]){
				a[j]=a[j+1]+a[j];
				a[j+1]=a[j]-a[j+1];
				a[j]=a[j]-a[j+1];
			}
		}
	}cout<<a;
	return 0;
}

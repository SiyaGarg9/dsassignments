#include <iostream>
using namespace std;

int main() {
    int n = 3;

    //Diagonal Matrix
    int diag[3] ;
    diag[0] = 5; diag[1] = 9; diag[2] = 3;

    cout << "Diagonal Matrix:" << endl;
    for(int i=0;i<n;i++) {
        for(int j=0;j<n;j++) {
            if(i==j) cout << diag[i] << " ";
            else cout << "0 ";
        }
        cout <<"\n";
    }

    //Tridiagonal Matrix
    int tri[3*n-2];
 
    tri[0] = 4; tri[1] = 5; tri[2] = 9;

    tri[n+0] = 2; tri[n+1] = 3;
    tri[2*n-1+0] = 7; tri[2*n-1+1] = 8;

    cout << "\nTridiagonal Matrix:" << endl;
    for(int i=0;i<n;i++) {
        for(int j=0;j<n;j++) {
            if(i==j) cout << tri[i] << " ";
            else if(i==j+1) cout << tri[n+i-1] << " ";
            else if(j==i+1) cout << tri[2*n-1+i] << " ";
            else cout << "0 ";
        }
        cout << endl;
    }

    //Lower Triangular Matrix
    int lower[n*(n+1)/2] = {0};
    int val=1;
    for(int i=0;i<n;i++) {
        for(int j=0;j<=i;j++) {
            lower[i*(i+1)/2 + j] = val++;
        }
    }

    cout << "\nLower Triangular Matrix:" << endl;
    for(int i=0;i<n;i++) {
        for(int j=0;j<n;j++) {
            if(i>=j) cout << lower[i*(i+1)/2 + j] << " ";
            else cout << "0 ";
        }
        cout << endl;
    }

    // (d) Upper Triangular Matrix
    int upper[n*(n+1)/2] = {0};
    val=1;
    for(int i=0;i<n;i++) {
        for(int j=i;j<n;j++) {
            upper[i*n - (i*(i-1))/2 + (j-i)] = val++;
        }
    }

    cout << "\nUpper Triangular Matrix:" << endl;
    for(int i=0;i<n;i++) {
        for(int j=0;j<n;j++) {
            if(i<=j) cout << upper[i*n - (i*(i-1))/2 + (j-i)] << " ";
            else cout << "0 ";
        }
        cout << endl;
    }

    // (e) Symmetric Matrix
    int sym[n*(n+1)/2] = {0};
    val=1;
    for(int i=0;i<n;i++) {
        for(int j=0;j<=i;j++) {
            sym[i*(i+1)/2 + j] = val++;  
        }
    }

    cout << "\nSymmetric Matrix:" << endl;
    for(int i=0;i<n;i++) {
        for(int j=0;j<n;j++) {
            if(i>=j) cout << sym[i*(i+1)/2 + j] << " ";
            else cout << sym[j*(j+1)/2 + i] << " ";
        }
        cout << endl;
    }

    return 0;
}


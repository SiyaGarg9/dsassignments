#include <iostream>
using namespace std;
void merge(int a[],int left,int mid,int right){
	int n1=mid-left+1;
	int n2=right-mid;
	int l[n1],r[n2];
	int i=0, j=0;
	for ( i = 0; i < n1; i++)
        l[i] = a[left + i];
    for ( j = 0; j < n2; j++)
        r[j] = a[mid + 1 + j];
        i=0,j=0;
        int k=left;
        while (i < n1 && j < n2) {
        if (l[i] <= r[j]) {
            a[k] = l[i];
            i++;
        } else {
            a[k] = r[j];
            j++;
        }
        k++;
    }
       while (i < n1) {
        a[k] = l[i];
        i++;
        k++;
    } 
    while (j < n2) {
        a[k] = r[j];
        j++;
        k++;
    }
        
        
}
void mergesort(int a[], int left,int right){
	if (left >= right)
        return; 
        
        
        int mid=left+(right-left)/2;
        mergesort(a,left,mid);
        mergesort(a,mid+1,right);
        merge(a,left,mid,right);
        
}
int main(){
	int a[10],i;
	for(i=0; i<=9; i++){
		cout<<"Enter the element ";
		cin>>a[i];
	}
	int n=0;
	for(i=0; i<=9; i++){
		n=n+1;
	}
	mergesort(a,0,n-1);
	for(i=0; i<n; i++){
		cout<<a[i];
		}
}

#include<iostream>
using namespace std;
int partition(int a[],int low, int high){
	
	int p=a[high];
	int i=low-1;
	int j;
	for(j=low; j<=high-1; j++){
		if(a[j]<p){
			i++;
			swap(a[i],a[j]);
		}
	}
	swap(a[i+1],a[high]);
	return i+1;
	
}
void swap(int &a, int &b) {
    int temp = a;
    a = b;
    b = temp;
}
void quicksort(int a[],int low , int high){
	if(low<high){
		int p=partition(a,low,high);
		quicksort(a, low, p - 1); // Sort left part
        quicksort(a, p + 1, high); 
	}
	
}
int main(){
	int a[10],i;
	for(i=0; i<=9; i++){
		cout<<"Enter the element ";
		cin>>a[i];
	}
	int n=0;
	for(i=0; i<=9; i++){
		n=n+1;
	}
	quicksort(a,0,n-1);
	for(i=0; i<n; i++){
		cout<<a[i];
	}
}

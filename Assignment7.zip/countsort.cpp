#include <iostream>
using namespace std;

void countSort(int a[], int size) {
  int output[10];
  int count[10];
  int max = a[0];

  for (int i=1; i<size; i++) {
    if (a[i]>max)
      max=a[i];
  }
  for (int i=0; i<=max; ++i) {
    count[i]=0;
  }
  for (int i=0; i<size; i++) {
    count[a[i]]++;
  }
  for (int i=1; i<=max;i++) {
    count[i] += count[i - 1];
  }
  for (int i=size- 1; i>=0;i--) {
    output[count[a[i]] -1] = a[i];
    count[a[i]]--;
  }

  for (int i=0; i<size;i++) {
    a[i]=output[i];
  }
}
void printArray(int a[], int size) {
  for (int i=0;i<size;i++)
    cout <<a[i] << " ";
  cout<<endl;
}

int main() {
  int array[] = {4, 2, 2, 8, 3, 3, 1};
  int n = sizeof(array) / sizeof(array[0]);
  countSort(array, n);
  printArray(array, n);
}

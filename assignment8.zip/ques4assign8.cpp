#include <iostream>
using namespace std;

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x) : val(x), left(NULL), right(NULL) {}
};

bool isBSTU(TreeNode* root, long long minVal, long long maxVal) {
    if (root == NULL)
        return true;

    if (root->val <= minVal || root->val >= maxVal)
        return false;

    return isBSTU(root->left, minVal, root->val) &&
           isBSTU(root->right, root->val, maxVal);
}

bool isBST(TreeNode* root) {
    return isBSTU(root, LLONG_MIN, LLONG_MAX);
}

int main() {
   

    TreeNode* root = new TreeNode(4);
    root->left = new TreeNode(2);
    root->right = new TreeNode(6);
    root->left->left = new TreeNode(1);
    root->left->right = new TreeNode(3);
    root->right->left = new TreeNode(5);
    root->right->right = new TreeNode(7);

    if (isBST(root))
        cout << "The tree is a BST";
    else
        cout << "The tree is NOT a BST";

    return 0;
}


#include <iostream>
using namespace std;

class MaxHeap {
    int heap[100];
    int size;

public:
    MaxHeap() { size = 0; }

    void insert(int x) {
        heap[size] = x;
        int i = size;
        size++;

        while (i > 0 && heap[(i-1)/2] < heap[i]) {
            swap(heap[(i-1)/2], heap[i]);
            i = (i-1)/2;
        }
    }

    int getMax() {
        if (size == 0) return -1;
        return heap[0];
    }

    int extractMax() {
        if (size == 0) return -1;

        int root = heap[0];
        heap[0] = heap[size - 1];
        size--;

        heapify(0);
        return root;
    }

    void heapify(int i) {
        int largest = i;
        int left = 2*i + 1;
        int right = 2*i + 2;

        if (left < size && heap[left] > heap[largest])
            largest = left;

        if (right < size && heap[right] > heap[largest])
            largest = right;

        if (largest != i) {
            swap(heap[i], heap[largest]);
            heapify(largest);
        }
    }

    bool isEmpty() {
        return size == 0;
    }
};


#include <iostream>
using namespace std;
class Node {
public:
    int data;
    Node* left;
    Node* right;
};
Node* searchRecursive(Node* root, int key) {
    if (root == NULL || root->data == key)
        return root;

    if (key < root->data)
        return searchRecursive(root->left, key);
    else
        return searchRecursive(root->right, key);
}

Node* searchNonRecursive(Node* root, int key) {
    while (root != NULL) {
        if (root->data == key)
            return root;
        else if (key < root->data)
            root = root->left;
        else
            root = root->right;
    }
    return NULL;
}
Node* findMin(Node* root) {
    if (root == NULL) return NULL;
    while (root->left!=NULL)
        root=root->left;
    return root;
}

Node* findMax(Node* root) {
    if (root == NULL) return NULL;
    while (root->right != NULL)
        root = root->right;
    return root;
}

Node* inorderSuccessor(Node* root, Node* target) {
    if (target==NULL) return NULL;

    if (target->right!= NULL)
        return findMin(target->right);

    Node* successor=NULL;
    Node* ancestor=root;

    while (ancestor!=target) {
        if (target->data<ancestor->data) {
            successor=ancestor;
            ancestor=ancestor->left;
        } else {
            ancestor=ancestor->right;
        }
    }
    return successor;
}

Node* inorderPredecessor(Node* root, Node* target) {
    if (target==NULL) return NULL;

    if (target->left!=NULL)
        return findMax(target->left);

    Node* predecessor=NULL;
    Node* ancestor=root;

    while (ancestor!= target) {
        if (target->data > ancestor->data) {
            predecessor = ancestor;
            ancestor = ancestor->right;
        } else {
            ancestor = ancestor->left;
        }
    }
    return predecessor;
}

void inorder(Node* temp) {
    if (temp != NULL) {
        inorder(temp->left);
        cout << temp->data << " ";
        inorder(temp->right);
    }
}

int main() {
    int choice;
    Node *root = NULL, *ptr, *temp;

    while (true) {
        cout << "\n1.Insert\n2.Display(Inorder)\n3.Search Recursive";
        cout << "\n4.Search Non-Recursive\n5.Minimum\n6.Maximum";
        cout << "\n7.Inorder Successor\n8.Inorder Predecessor\n9.Exit\n";
        cin >> choice;

        if (choice == 1) {
            ptr = new Node();
            cout<<"Enter value: ";
            cin>>ptr->data;
            ptr->left=ptr->right = NULL;

            if (root==NULL) {
                root=ptr;
            } else {
                temp=root;
                while(true) {
                    if(ptr->data<temp->data) {
                        if (temp->left==NULL) {
                            temp->left=ptr;
                            break;
                        }
                        temp = temp->left;
                    } else {
                        if (temp->right == NULL) {
                            temp->right = ptr;
                            break;
                        }
                        temp = temp->right;
                    }
                }}}

        else if (choice == 2) {
            inorder(root);
        }
        else if (choice == 3) {
            int key;
            cout << "Enter value to search: ";
            cin >> key;
            Node* res = searchRecursive(root, key);
            if (res) cout << "Found\n";
            else cout << "Not Found\n";
        }

        else if (choice == 4) {
            int key;
            cout << "Enter value to search: ";
            cin >> key;
            Node* res = searchNonRecursive(root, key);
            if (res) cout << "Found\n";
            else cout << "Not Found\n";
        }

        else if (choice == 5) {
            Node* m = findMin(root);
            if (m) cout << "Minimum = " << m->data << endl;
        }

        else if (choice == 6) {
            Node* m = findMax(root);
            if (m) cout << "Maximum = " << m->data << endl;
        }

        else if (choice == 7) {
            int key;
            cout << "Enter node value: ";
            cin >> key;
            Node* target = searchNonRecursive(root, key);
            Node* suc = inorderSuccessor(root, target);
            if (suc) cout << "Successor = " << suc->data << endl;
            else cout << "No Successor\n";
        }

        else if (choice == 8) {
            int key;
            cout << "Enter node value: ";
            cin >> key;
            Node* target = searchNonRecursive(root, key);
            Node* pre = inorderPredecessor(root, target);
            if (pre) cout << "Predecessor = " << pre->data << endl;
            else cout <<"No Predecessor\n";
        }

        else if (choice == 9) {
            break;
        }
    }
}


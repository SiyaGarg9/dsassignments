#include <iostream>
using namespace std;
int main() {
    string str;
    cin >> str;

    int f[300] = {0};
    char q[100];   
    int front = 0, rear = -1;
    for (int i = 0; i < str.size(); i++) {
        char ch = str[i];
        f[ch]++;

        q[++rear] = ch;

        while (front <= rear && f[q[front]] > 1) {
            front++;
        }

        if (front > rear) cout << -1 << " ";
        else cout << q[front] << " ";
    }
}




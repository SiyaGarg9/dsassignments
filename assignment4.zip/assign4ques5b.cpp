#include <iostream>
using namespace std;
class Stack {
    int q[100];
    int f, r;
public:
    Stack(){ 
	   f=0; r=-1; 
	}

    bool isEmpty() {return(f>r); 
	}

    void push(int x) {
        q[++r] = x;
      
        for (int i=f; i<r; i++) {
            q[++r]=q[f++];
        }
        cout<<x<<" pushed\n";
    }

    void pop() {
        if (isEmpty()) {
            cout << "Stack empty\n";
            return;
        }
        cout<<q[f++]<<" popped\n";
    }

    void display() {
        if (isEmpty()) {
            cout << "Stack empty\n";
            return;
        }
        for (int i=f; i<= r; i++) 
		cout<<q[i]<<" ";
        cout<<endl;
    }
};

int main() {
    Stack s;
    s.push(10);
    s.push(20);
    s.push(30);
    s.display();
    s.pop();
    s.display();
}


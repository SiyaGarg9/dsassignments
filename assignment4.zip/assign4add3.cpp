#include <iostream>
using namespace std;

bool checkSorted(int arr[], int n) {
    int stack[100], top = -1;
    int e=1;

    for (int i=0; i<n; i++) {
        int curr = arr[i];
        while (top!=-1 && stack[top] == e) {
            top--;
            e++;
        }

        if (curr==e) {
            e++;
        } else {
            stack[++top]=curr;  
        }
    }

    while (top!=-1&&stack[top]==e) {
        top--;
        e++;
    }

    return (e==n+1);
}

int main() {
    int arr[] = {5, 1, 2, 3, 4};
    int n = sizeof(arr)/sizeof(arr[0]);

    if (checkSorted(arr, n))
        cout << "Yes, can be arranged in increasing order.\n";
    else
        cout << "No, cannot be arranged.\n";

    return 0;
}


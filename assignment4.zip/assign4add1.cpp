#include <iostream>
using namespace std;
void Binary(int n) {
    for (int i=1; i<= n; i++) {
        int num=i, b=0, p=1;
        while (num>0) {
            b=(num % 2)*p+b;
            num/=2;
            p*= 10;
        }
        cout<<b;
        if(i<n)cout<<", ";
    }
}

int main() {
    int n;
    cout<<"Enter n: ";
    cin>>n;
   Binary(n);
    return 0;
}



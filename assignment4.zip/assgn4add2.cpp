#include <iostream>
using namespace std;
#define SIZE 100
struct Queue {
    int arr[SIZE];
    int front, rear;

    Queue() {
        front=0;
        rear=-1;
    }

    bool isEmpty() {
        return (front>rear);
    }

    void enqueue(int x) {
        arr[++rear]=x;
    }

    int dequeue() {
        return arr[front++];
    }
};

void sortQueue(Queue &q) {
    int n=q.rear-q.front+1;

    for (int i=0; i<n;i++) {
        int minIndex ;
        int minVal;  

        for (int j=0; j<n; j++) {
            int curr=q.dequeue();
            if (j <n-i && curr<minVal) {
                minVal=curr;
                minIndex=j;
            }
            q.enqueue(curr);
        }

        for (int j=0; j<n; j++) {
            int curr=q.dequeue();
            if (j!=minIndex) {
                q.enqueue(curr);
            }
        }
     
        q.enqueue(minVal);
    }
}

int main() {
    Queue q;
    q.enqueue(30);
    q.enqueue(11);
    q.enqueue(15);
    q.enqueue(4);
    sortQueue(q);
    cout << "Sorted Queue: ";
    while (!q.isEmpty()) {
        cout << q.dequeue() << " ";
    }
    return 0;
}


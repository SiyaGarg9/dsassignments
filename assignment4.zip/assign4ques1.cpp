#include <iostream>
using namespace std;
class Queue {
    int arr[5];
    int front, rear;

public:
    Queue() {
        front = -1;
        rear = -1;
    }

    bool isEmpty() {
        return (front==-1);
    }

    bool isFull() {
        return (rear==4);
    }
    void enqueue(int value) {
        if (isFull()) {
            cout << "Queue is full" << endl;
        } else {
            if (front == -1) front = 0; 
            arr[++rear] = value;
            cout <<value<<" enqueued into queue" << endl;
        }
    }

    void dequeue() {
        if (isEmpty()) {
            cout<< "Queue is empty" << endl;
        } else {
            cout<< arr[front] << " dequeued from queue" << endl;
            if (front == rear) {
             
                front = rear = -1;
            } else {
                front++;
            }
        }
    }

    void peek() {
        if (isEmpty()) {
            cout<< "Queue is empty" << endl;
        } else {
            cout<< "Front element is: "<< arr[front] << endl;
        }
    }

    void display() {
        if (isEmpty()) {
            cout << "Queue is empty" << endl;
        } else {
            cout << "Queue elements: ";
            for (int i = front; i<= rear; i++) {
                cout <<arr[i] << " ";
            }
            cout<<endl;
        }
    }
};

int main() {
    Queue q;
    int choice, value;
    while (true) {
        cout << "\nQueue Menu";
        cout << "\n1 Enqueue";
        cout << "\n2 Dequeue";
        cout << "\n3 Peek";
        cout << "\n4 Display";
        cout << "\n5 Check if Empty";
        cout << "\n6 Check if Full";
        cout << "\n7 Exit";
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value to enqueue: ";
            cin >> value;
            q.enqueue(value);
            break;
        case 2:
            q.dequeue();
            break;
        case 3:
            q.peek();
            break;
        case 4:
            q.display();
            break;
        case 5:
            if (q.isEmpty()) cout << "Queue is Empty" <<endl;
            else{
			 cout<< "Queue is NOT Empty" << endl;}
            break;
        case 6:
            if (q.isFull()) cout<<"Queue is Full"<< endl;
            else {
			cout << "Queue is NOT Full" << endl;}
            break;
        case 7:
            cout << "Exiting program"<<endl;
            return 0;
        default:
            cout << "Invalid choice" << endl;
        }
    }
}


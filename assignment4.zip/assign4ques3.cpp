#include <iostream>
using namespace std;
int main() {
    int n;
    cout << "Enter number of elements: ";
    cin >>n;

    int arr[n];
    cout<< "Enter " <<n<< " elements: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    cout << "\nOriginal queue: ";
    for (int i=0; i<n; i++) {
        cout <<arr[i]<<" ";
    }
    cout << endl;
    int half = n/2;
    int result[n], idx = 0;

    for (int i= 0;i<half; i++) {
        result[idx++]=arr[i];       
        result[idx++]=arr[i+half]; 
    }
    cout << "Interleaved Queue: ";
    for (int i=0; i<n; i++) {
        cout<<result[i] << " ";
    }
    cout << endl;

    return 0
	;
}


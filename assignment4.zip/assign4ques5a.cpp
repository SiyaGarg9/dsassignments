#include <iostream>
using namespace std;
class Stack {
    int q1[100], q2[100];
    int f1, r1, f2, r2;
public:
    Stack() { f1 = f2 = 0; r1 = r2 = -1; }
    bool isEmpty() { return (f1 > r1); }
    void push(int x) {
        q1[++r1] = x;
        cout << x << " pushed\n";
    }
    void pop() {
        if (isEmpty()) {
            cout << "Stack is empty\n";
            return;
        }
     
        while (f1 < r1) {
            q2[++r2] = q1[f1++];
        }
        cout << q1[f1] << " popped\n";
        f1++; 

        f1=0; r1= r2;
        for(int i=0; i<=r2; i++) q1[i]=q2[i];
        f2=0; r2=-1;
    }

    void display() {
        if (isEmpty()) {
            cout <<"Stack empty\n";
            return;
        }
        for (int i=f1; i<=r1; i++) cout<<q1[i]<< " ";
        cout << endl;
    }
};

int main() {
    Stack s;
    s.push(10);
    s.push(20);
    s.push(30);
    s.display();
    s.pop();
    s.display();
}


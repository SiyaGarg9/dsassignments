#include <iostream>
using namespace std;
class Node{
	public:
	int data;
	Node *Next;
};
int main(){
  Node *Start= NULL, *ptr, *temp, *prev;
int i;
  
  while(1==1){
  	cout<<"\n1 to insert valued in linked list";
  	cout<<"\n2 to display values ";
  	cout<<"\n3 to delete all occurances";
  	cin>>i;

	  if(i==1){
	  
  	ptr= new Node();
  	cin>>ptr->data;
  	ptr->Next=NULL;
  	if(Start==NULL){
  		Start=ptr;
	  }else{
	  	temp=Start;
	  	while(temp->Next!=NULL){
	  		temp=temp->Next;
		  }
	  	temp->Next=ptr;
	  }
	  
	  }
	  if(i==2){
	  	temp=Start;
  		while(temp!=NULL){
  			cout<<temp->data;
  			temp=temp->Next;
		  }
	  }
	  if(i==3){
	  	int key, m = 0;
            cout << "Enter the key to delete (all occurrences): ";
            cin >> key;

            temp = Start;
            prev = NULL;

            while (temp != NULL) {
                if (temp->data == key) {
                    m++;

                    if (temp == Start) { 
                        Start = Start->Next;
                       
                        temp = Start;
                    } else {  
                        prev->Next = temp->Next;
                      
                        temp = prev->Next;
                    }
                } else {
                    prev = temp;
                    temp = temp->Next;
                }
            }

            cout << "The given key occurred and was deleted " << m << " times\n";
}
	  }
}
	  
	  
	  
	  
	  

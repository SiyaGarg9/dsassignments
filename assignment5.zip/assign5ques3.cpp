#include <iostream>
using namespace std;
class Node{
	public:
	int data;
	Node *Next;
};
int main(){
  Node *Start= NULL, *ptr, *temp;
int i;
  
  while(1==1){
  	cout<<"\n1 to insert valued in linked list";
  	cout<<"\n2 to display values ";
  	cout<<"\n3 to find middle of linked list";
  	cin>>i;

	  if(i==1){
	  
  	ptr= new Node();
  	cin>>ptr->data;
  	ptr->Next=NULL;
  	if(Start==NULL){
  		Start=ptr;
	  }else{
	  	temp=Start;
	  	while(temp->Next!=NULL){
	  		temp=temp->Next;
		  }
	  	temp->Next=ptr;
	  }
	  
	  }
	  if(i==2){
	  	temp=Start;
  		while(temp!=NULL){
  			cout<<temp->data;
  			temp=temp->Next;
		  }
	  }
	  if(i==3){
	  	if (Start==NULL) {
                cout << "List is empty\n";
            } else {
            	Node *temp2 = Start, *temp1 = Start;
                while (temp1!= NULL &&temp1->Next != NULL) {
                    temp2=temp2->Next;
                    temp1= temp1->Next->Next;
                }
                cout << "Middle element is: " <<temp2->data << endl;
	  }
	  
	  
}
	  }
	  }

#include <iostream>
using namespace std;
class Node{
	public:
	int data;
	Node *Next;
	
};
int main(){
Node *Start= NULL, *ptr, *temp, *temp1,*temp2;
  int i;
  while(1==1){
  	cout<<"\n1 to enter the data \n2 to insert at beginning \n3 to insert at end \n4 for insertion in between \n5 for deletion at beginning ";
  	cout<<"\n6 for deletion from end \n7 for deletion for specific node \n8 for searching a node \n9 to display ";
  	cin>>i;
  	if(i==1){
	  
  	ptr= new Node();
  	cin>>ptr->data;
  	ptr->Next=NULL;
  	if(Start==NULL){
  		Start=ptr;
	  }else{
	  	temp=Start;
	  	while(temp->Next!=NULL){
	  		temp=temp->Next;
		  }
	  	temp->Next=ptr;
	  }}
  	if(i==2){
  		ptr=new Node();
	  	cin>>ptr->data;
	    ptr->Next=Start;
	    Start=ptr;
	  }
	  if(i==3){
	  	ptr =new Node();
		  cin>>ptr->data;
	  	temp=Start;
	  	while(temp->Next!=NULL){
	  		temp=temp->Next;
		  }
		  temp->Next=ptr;
	  }
	  if(i==4){
	  	int key,val;
            cout<<"Enter the value after which you want to insert: ";
            cin>>key;
            cout<<"Enter new node value: ";
            cin>>val;

            temp=Start;
            while(temp!=NULL&&temp->data!=key){
                temp=temp->Next;
            }

            if(temp==NULL) {
                cout<<"Node with value"<<key<<" not found\n";
            } else {
                ptr = new Node();
                ptr->data=val;
                ptr->Next=temp->Next;
                temp->Next=ptr;
                cout<<"Inserted "<<val <<" after "<< key <<"\n";
            }
	  }
	  if(i==5){
	  	if(Start==NULL) {
                cout <<"List is empty\n";
            } else {
                temp = Start;
                Start = Start->Next;
	  }
	  }
	  if(i==6){
	  	temp=Start;
	  	while(temp->Next!=NULL){
	  		temp1=temp;
	  		temp=temp->Next;
		  }
		  temp1->Next=NULL;
	  	
	  }
	  if(i==7){
	  	int key;
            cout<<"Enter value to delete: ";
            cin>>key;
	  	temp2=Start;
                temp=Start->Next;
                while(temp!= NULL&&temp->data!= key) {
                    temp2=temp;
                    temp=temp->Next;
                }
                if(temp==NULL) {
                    cout<<"Node with value "<<key<<" not found.\n";
                } else {
                    temp2->Next = temp->Next;
                    cout << "Deleted node with value: " << temp->data <<"\n";
                    
                }
	  	
	  }
	  if(i==8){
	  	int key, pos=1;
            cout << "Enter value to  be searched ";
            cin >> key;
            temp=Start;
            while (temp!=NULL) {
                if (temp->data==key) {
                    cout <<"Node with value "<<key<<" found at position"<<pos<<"\n";
                }
                temp=temp->Next;
                pos++;
                
            }

            
	  	
	  }
	  if(i==9){
	  	temp=Start;
  		while(temp!=NULL){
  			cout<<temp->data;
  			temp=temp->Next;
		  }
	  	
	  }
	  
  }


}

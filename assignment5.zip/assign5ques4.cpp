#include <iostream>
using namespace std;
class node{
	public:
	int data;
	node *Next;	
};
int main(){
	node *Start= NULL, *ptr , *temp,*temp1, *temp2 ;
	int i;
	
	while(1==1){ 
	cout<<"\n1 to insert valued in linked list";
  	cout<<"\n2 to display values "; 
    cout<<"\n3 reverse of the linked list ";
cin>>i;

     
	if(i==1){
	ptr=new node();
	cin>>ptr->data;
	ptr->Next=NULL;
	if(Start==NULL){
		Start=ptr;
	}
	else{
		temp=Start;
		while(temp->Next!=NULL){
			temp=temp->Next;
		}
		temp->Next=ptr;
	}	
}  
	if(i==2){
	
	temp=Start;
	while(temp!=NULL){
		cout<<temp->data;
		temp=temp->Next;
	}}
	if(i==3){
		temp=Start;
		 temp1=temp->Next;
		 
		 while(temp2!=NULL){
		 	 temp2=temp1->Next;
		 	 temp1->Next=temp;
		 	 temp=temp1;
		 	 temp1=temp2;
	} 
	          Start->Next=NULL;
	          Start=temp;
		
		
		
		
		
	}
}}
